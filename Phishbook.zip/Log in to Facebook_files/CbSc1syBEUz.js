if (self.CavalryLogger) { CavalryLogger.start_js(["mO2RUoG"]); }

__d("ReactDOM",["ReactDOMLegacy_DEPRECATED"],(function(a,b,c,d,e,f){Object.keys(importNamespace("ReactDOMLegacy_DEPRECATED")).forEach(function(a){if(a==="default"||a==="__esModule")return;f[a]=importNamespace("ReactDOMLegacy_DEPRECATED")[a]})}),null);